This is a Super Metroid inspired game made using OpenGL in C++

The player is capable of moving Samus left or right, jumping, and shooting.
There is an initial spawn room with one Metroid enemy and once the player kills
the enemy, they can move on to the next room. 
In the next room, there is a boss battle. 
Once the player beats the boss, they win.