#include "Bullet.h"
#include <deque>

Bullet::Bullet(){}